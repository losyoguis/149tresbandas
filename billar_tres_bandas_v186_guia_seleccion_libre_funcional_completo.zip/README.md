# Billar tres bandas v162 — guía exacta desde imagen 2

Versión funcional completa con la jugada 080 eliminada y 148 jugadas jugables.

## Cambios v162

- La guía de referencia de cada jugada ya no se dibuja con puntos inventados.
- Se generó una imagen transparente `guia_referencia.png` para cada jugada, extraída directamente desde `recorrido_guia.webp` — la imagen 2 de cada carambola.
- La mesa muestra esa guía exacta cuando está activo el modo práctica y la guía está encendida.
- Se mantiene el disparo real: si el usuario taca mal, la bola sigue su trayectoria física normal y no se fuerza la carambola.
- El botón **Demostración** sigue usando la ruta modelo para estudiar la jugada.
- Se conserva la sincronización especial del video para las jugadas 115, 127, 132, 134, 135, 136, 140, 147 y 149.
- Si hay bola receptora en la guía dinámica, se muestra con el color real; si no hay bola receptora activa, no se muestra nada.

## Control de calidad incluido

- `qa_guia_referencia_imagen2_v162.json`: reporte de extracción y validación de las 148 guías desde la imagen 2.
- `qa_control_calidad_v161.json`
- `qa_guia_dinamica_v161.json`
- `qa_tiro_real_v160.json`

## Estructura relevante

Cada jugada tiene:

- `posicion_inicial.webp`
- `recorrido_guia.webp`
- `guia_referencia.png`


## Nota de extracción

En las jugadas donde la imagen 2 no trae recorrido visible suficiente, la guía se deja transparente para no inventar trayectorias. En esta versión quedaron sin guía visual extraída: 046 y 079.


Actualización v165: reemplazadas las imágenes de la jugada 042 (posición inicial y recorrido guía) con el material enviado por el usuario. La guía de referencia se regeneró a partir de la diferencia entre imagen 1 e imagen 2.

Actualización v166: reemplazadas las imágenes de la jugada 044 (posición inicial y recorrido guía) con el material enviado por el usuario. La guía de referencia se regeneró desde la imagen 2 comparada con la imagen 1.

Actualización v167: reemplazadas las imágenes de la jugada 045 (posición inicial y recorrido guía) con el material enviado por el usuario. La guía de referencia se regeneró desde la imagen 2 comparada con la imagen 1.

Actualización v168: reemplazadas las imágenes de la jugada 046 (posición inicial y recorrido guía) con el material enviado por el usuario. La guía de referencia se regeneró desde la imagen 2 comparada con la imagen 1.

Actualización v169: reemplazadas las imágenes de la jugada 058 (posición inicial y recorrido guía) con el material enviado por el usuario. La guía de referencia se regeneró desde la imagen 2 comparada con la imagen 1.

Control de calidad v170: integradas definitivamente las jugadas 042, 044, 045, 046 y 058 con sus nuevas imágenes (posición inicial y recorrido guía). Validado el paquete completo: 148 jugadas activas, 296 imágenes WEBP, guías de referencia presentes por jugada, selector sin la 080, y assets listos para carga.

Control de calidad visual v172: la guía principal de todas las jugadas se suavizó para que se vea como la referencia deseada (más sutil y elegante, similar a la imagen 2). Se redujo la intensidad del brillo, se limpiaron artefactos pequeños y se mantuvo la trayectoria exacta de cada jugada.

Actualización v173: la guía dinámica en modo Imagen jugada usa el efecto visual exacto del punto azul de la imagen/modal. Se agregaron correcciones de efecto para las jugadas 044 y 046 actualizadas, se conserva el efecto al mover el taco y la mini-guía sigue la dirección del taco.


## Actualización v174

- **Móvil corregido:** la botonera principal ya no queda fija encima de la mesa; los controles quedan debajo para no tapar la jugada.
- **Tirar = física real:** el botón **Tirar** nunca ejecuta la ruta calibrada ni suma punto de forma forzada. La bola sale hacia donde apunta el taco.
- **Demostración = ruta modelo:** la ejecución exacta de la jugada queda reservada únicamente para **Demostración**.
- **Código refactorizado:** CSS y JavaScript se separaron en `css/styles.css` y `js/app.js`; `index.html` queda más limpio para mantenimiento y alojamiento en GitHub Pages / Google Sites.
- **Física refinada:** se ajustaron rebote de bandas, restitución de bolas, fricción tangencial de banda, transferencia de efecto y velocidad de bolas objetivo para un comportamiento menos exagerado y más estable.


## Actualización v175
- Potencia extendida hasta 160% para tiros largos de tres bandas.
- Detección automática de jugadas largas según longitud de la guía y descripción técnica.
- El taco mantiene el comportamiento normal hasta 100% y permite una reserva progresiva al halarlo más atrás.
- Aviso visual de tiro largo y recomendación de potencia cuando la jugada requiere más recorrido.
- Física recalibrada solo para tiros largos: menos pérdida por fricción, rebote de banda más vivo y efecto lateral más sostenido.
- Tirar sigue siendo física real; Demostración sigue reservada para la ruta modelo exacta.


## Actualización v176 — física profesional

- **Motor de paño estable:** se eliminó la física especial que cambiaba fricción y rebote solo por ser tiro largo. La potencia extendida sigue disponible, pero la mesa conserva un comportamiento único y más realista.
- **Bandas más reales:** el rebote ahora depende de ángulo de llegada, velocidad, pérdida tangencial y efecto lateral. El efecto a favor abre la ruta y el contrario la cierra con más naturalidad.
- **Efecto con vida propia:** la blanca conserva y pierde efecto progresivamente por paño, banda y choque, con una curvatura leve por efecto lateral sin exagerar el movimiento.
- **Choques por grosor:** se mejoró el throw entre bolas, la pérdida por deslizamiento y la transferencia de corrido/retroceso para que los impactos se sientan menos mecánicos.
- **Guía predictiva:** la línea de tiro se calcula con el mismo motor profesional del disparo real, para que el usuario vea una predicción física y no una carambola forzada.
- **Demostración sin puntaje:** el botón Demostración queda como estudio de la ruta modelo; no suma puntos ni intentos. Solo Tirar cuenta como práctica real.
- **Diagnóstico técnico:** después de fallar en modo práctica, la app entrega una corrección más útil: potencia, bandas, orden de bolas, grosor, efecto o cierre.

Versión recomendada para alojar en GitHub Pages o incrustar en Google Sites como entrenador final de billar tres bandas.


## v177 - Guía dinámica sincronizada con tiro real

Corrección aplicada después de detectar desfase entre la guía amarilla y el recorrido blanco real de la tacada:

- La guía dinámica y el botón **Tirar** usan la misma física de paño, banda, efecto y choque.
- El modo de tiro largo ya no se calcula distinto entre predicción y ejecución.
- El decaimiento de efecto al tocar banda/bola queda sincronizado.
- La colisión entre bolas en la guía replica la corrección física del tiro real.
- La ruta predictiva usa más pasos para no cortar recorridos de 3, 4 o 5 bandas.

Resultado esperado: lo que se muestra en la guía amarilla debe corresponder a lo que hace la bola blanca al disparar, sin rutas desfasadas.


## v178 - Guía maestra sincronizada con video

Corrección aplicada a partir de los pantallazos donde se veía una ruta calculada y otra ruta ejecutada. En modo **Imagen jugada** ahora se muestra una sola guía principal: la línea punteada corresponde a la ruta maestra del video y el botón **Tirar** ejecuta esa misma trayectoria mientras el usuario no modifique taco, potencia, efecto ni posición de bolas.

Cambios clave:

- Se evita la superposición confusa entre ruta de referencia, guía predictiva y estela real.
- En práctica con Imagen jugada armada, la guía visible y la tacada exacta usan el mismo `guidePath`.
- Si el usuario mueve manualmente el taco, cambia potencia/efecto o reubica bolas, la guía pasa a predicción física libre y se avisa que la sincronización maestra fue desactivada.
- **Demostración** conserva su función de estudio y no suma puntos ni intentos.
- **Tirar** en guía maestra sí suma intento y punto cuando completa la carambola.
- Service worker actualizado a v178 para evitar caché antiguo.


## v179 - Guía principal automática al seleccionar jugada

Corrección solicitada:

- Al seleccionar una jugada desde el selector, la mesa activa inmediatamente la guía principal.
- La guía principal se marca visualmente con una banda verde luminosa debajo de la línea punteada amarilla.
- La banda verde y la línea amarilla usan exactamente los mismos puntos de la ruta maestra; no son dos cálculos diferentes.
- Si se presiona Tirar sin modificar taco, potencia, efecto o bolas, la tacada sigue esa misma guía visible.
- Si el jugador modifica el taco, potencia, efecto o posición de las bolas, la banda verde se oculta y queda la predicción física libre del ajuste manual.
- Service worker actualizado a v179 para evitar caché viejo en navegador/PWA.


## v180 - Guía principal persistente durante la tacada

Corrección solicitada:

- La guía principal verde de la jugada queda siempre visible al seleccionar una carambola.
- La guía principal ya no se borra al presionar **Tirar**, al hacer doble toque ni mientras la bola blanca está rodando.
- Si el jugador modifica taco, potencia, efecto o bolas, la referencia principal verde permanece como ruta maestra de estudio.
- La línea amarilla puede seguir mostrando la predicción física del ajuste actual, pero la ruta principal no desaparece.
- En tiros sincronizados con Imagen jugada, la bola ejecuta la ruta visible y la guía queda como referencia durante todo el ataque.
- Service worker actualizado a v180 para evitar caché viejo en navegador/PWA.


## v181 - Modal de instrucciones para ejecutar la tacada

- Se agregó debajo del subtítulo principal un botón **Instrucciones**.
- El botón abre un modal accesible con los pasos para seleccionar jugada, observar video, memorizar figura, configurar efecto, apuntar, ajustar potencia y tirar.
- El modal se puede cerrar con la X, con el botón Entendido, clic fuera del panel o tecla Escape.
- Mientras el modal está abierto, Enter no ejecuta la tacada accidentalmente.
- Service worker actualizado a v181 para evitar caché viejo en navegador/PWA.


## v182 - Efecto sincronizado en guía dinámica

- El botón **Imagen jugada** fue renombrado a **Efecto**.
- En la guía dinámica, el **punto azul**, la **bola tacadora** y la **mini-guía** ahora usan la misma referencia de efecto para quedar sincronizados con mayor precisión respecto a la imagen de la jugada.
- Se unificó la escala visual del punto de efecto en:
  - control de efecto,
  - guía dinámica,
  - visor de contacto,
  - visor de bolas.
- Se conserva la guía principal persistente y la física libre profesional.
- Service worker actualizado a **v182** para evitar caché viejo.


## v183 - Efecto con precisión milimétrica

- El botón **Efecto** ahora no solo carga el punto azul y la potencia de referencia: también **reposiciona automáticamente el taco** con una corrección fina basada en la geometría visible de cada imagen.
- El cálculo combina:
  - solape visual entre bolas,
  - separación relativa,
  - lado del contacto,
  - microajuste derivado del ángulo mostrado en la imagen.
- Esto mejora la coincidencia entre la imagen de la jugada, la mini-guía y la tacada inicial cuando se selecciona una carambola.
- Service worker actualizado a **v183**.


## v184 - Imán inteligente de guía para carambola

- Se agregó un **imán inteligente** entre la guía principal verde y la guía de tacada.
- Cuando la guía de tacada se acerca a la ruta maestra de la jugada, la línea amarilla se engancha visualmente a la guía principal.
- Si el usuario tira con el imán activo, la app ejecuta la ruta maestra sincronizada para ayudar a completar la carambola.
- El imán solo actúa cuando hay cercanía real de trayectoria, dirección compatible, bolas en posición base y primera bola correcta.
- Si el jugador apunta lejos de la ruta, se mantiene la física libre profesional.
- Service worker actualizado a **v184**.


## v185 - Ajuste de instrucciones

- En el modal de **Instrucciones**, punto 1, se eliminó la frase “o el sistema de tres bandas”.
- El texto quedó: **Selecciona la jugada: Elige la carambola que deseas practicar.**
- Se conserva el imán de carambola, la guía principal persistente, el botón Efecto y la física profesional.
- Service worker actualizado a **v185** para evitar caché anterior.


## v186 - Guía libre al seleccionar jugada

- Al seleccionar una jugada, la **guía principal verde** queda visible como referencia, pero la **guía de tacada** ya no se arma automáticamente perfecta para hacer la carambola.
- La tacada inicia ligeramente separada de la ruta maestra para que el jugador deba ajustar dirección, potencia o efecto.
- El **imán de carambola** queda bloqueado justo al cargar la jugada y solo se activa después de que el jugador haga un ajuste y acerque la guía de tacada a la guía principal.
- El botón **Efecto** y **Alinear fácil** siguen disponibles para sincronizar la tacada con precisión cuando se desee.
- Service worker actualizado a **v186**.
